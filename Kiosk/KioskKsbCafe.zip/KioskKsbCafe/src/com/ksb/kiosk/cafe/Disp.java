package com.ksb.kiosk.cafe;

import com.ksb.util.Cw;

public class Disp {
String x = "x";	
	
	final static String DOT = "★";	
	final static int DOT_COUNT = 48;	
	public static void line() {	
		for(int i=0;i<DOT_COUNT;i=i+1) {
			Cw.w(DOT);
		}
		Cw.wn();
	}
	
	public static void title() {
		line();
		Cw.wn("     ******************** 카페123 *********************");
		line();
	}
}
