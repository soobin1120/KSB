package com.ksb.kiosk.cafe;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}

		

	}

