package com.ksb.kiosk.cafe;

import com.ksb.util.Cw;
public class ProcMenuDrink {
	public static void run() {
		for(Product p:KioskObj.products) {
			Cw.wn(p.name+" "+p.price +"원");
		}
		yy:while(true) {
			
			Cw.wn("[1.아메리카노/2. 라떼/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				ProcAmeOption.run();
				break;
			case "2":
				ProcLatteOption.run();
						break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
